# Chitkara-Grocery-Store
This is a website of an online grocery shopping platform developed using HTML, CSS and JS. This project involves only frontend coding languages. This was a group project and we will try to make it better. Any feedbacks are welcome on the project. One last thing, I am uploading the images used in this project but we have added the images using the URLs so there should be no need to add them again but still, for reference, we will be uploading the images.

![Screenshot 2022-01-26 185244](https://user-images.githubusercontent.com/97402437/161426477-67971e4b-5d03-43f5-82eb-6b5c392e2653.png)

![Screenshot 2022-01-26 185200](https://user-images.githubusercontent.com/97402437/161426498-f1562659-2055-4b4a-82a9-f9b7694c7f22.png)

![Screenshot 2022-01-24 213417](https://user-images.githubusercontent.com/97402437/161426503-968eea4c-5f58-4f65-9266-9a0fdf96f586.png)

![Screenshot 2022-01-24 213342](https://user-images.githubusercontent.com/97402437/161426513-002bc807-8451-45c2-9d2b-38a699204459.png)
